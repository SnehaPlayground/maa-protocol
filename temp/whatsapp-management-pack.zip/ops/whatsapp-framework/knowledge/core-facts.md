# Primeidea Core Facts

- Business: Primeidea Ventures
- Lead contact: Partha Shah
- Location: Vadodara, Gujarat, India
- Public login / self-start path: https://login.primeidea.in/pages/auth/login
- Website: https://www.primeidea.in/
- Public blog: https://www.primeidea.in/blogs
- Mobile app availability is referenced on the website for portfolio tracking.
- Primeidea focuses on financial planning, investment advisory, wealth-management-related services, retirement planning, legacy planning, tax planning, and insurance-related advisory support.

## Notes
- Keep factual statements tied to website-verifiable content where possible.
- If testimonial-based language is used in conversation, present it as client/testimonial language, not objective ranking fact.
