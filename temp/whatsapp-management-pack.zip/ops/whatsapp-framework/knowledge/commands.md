# Owner Commands

Only accept these from Partha:
- summarize-leads
- show-recent-inquiries
- export-logs
- send-to-group <group> <message>
- send-to-all-groups <message>
- pause-bot
- resume-bot
- silent-mode on
- silent-mode off

## Output rule
Reply only to Partha when acting on owner commands.
